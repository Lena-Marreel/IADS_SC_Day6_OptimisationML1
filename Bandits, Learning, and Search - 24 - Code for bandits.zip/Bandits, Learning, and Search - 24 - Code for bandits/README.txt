Main.py - run this to evaluate the algorithms, configure your experiment in there
Agent.py - add your code for bandit algorithms in there
Evaluator.py - no need to change
BanditSpecs.py - no need to change
BanditGenerator.py - no need to change