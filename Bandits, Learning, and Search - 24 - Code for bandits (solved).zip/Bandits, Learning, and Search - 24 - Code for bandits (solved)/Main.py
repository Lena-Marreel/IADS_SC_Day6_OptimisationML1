# ------------------------------------------
# Tom Vodopivec
#
# IADS Analytics, Data Science & Decision Making Summer School 2022
# Course: Bandits, Learning, and Search
# 2022-08-01
#
# ------------------------------------------

#-- imports --#
from BanditSpecs import *
from BanditGenerator import *
from Agent import *
from Evaluator import *
from Policies import *


###--- main program ---###

##-- generate all bandits
allCases = generateBandits(BANDITSPECS, suppress_output = 1)

##-- build evaluation Tests from generated bandits
testBatch_All = BanditTestBatch(allCases, range(len(allCases))) 	#All
testBatch_01_05 = BanditTestBatch(allCases, [0, 1, 2, 3, 4])  	#Example subset: first 5 cases
testBatch_2 = BanditTestBatch(allCases, [10, 11, 12, 13, 14, 5, 6, 7, 8])

##-- agent configuration
# solver = Agent(banditPolicy.RANDOM)
# solver = Agent(banditPolicy.EGREEDY, 0.10)
# solver = Agent(banditPolicy.SOFTMAX, 0.01)
# solver = Agent(banditPolicy.UCB1, 0.20)
solver = Agent(banditPolicy.UCBT, 0.40)

##-- evaluation
cases = testBatch_All
suppress_output = 0
num_repeats = 100
return_oracle_probablity = 0
results = evaluate(solver, cases, num_repeats, suppress_output, return_oracle_probablity)
print('Your selected algorithm: reward: %.1f' % results[0][0])