# ------------------------------------------
# Tom Vodopivec
#
# IADS Analytics, Data Science & Decision Making Summer School 2022
# Course: Bandits, Learning, and Search
# 2022-08-01
#
# ------------------------------------------

from Policies import *

# The Multi-Armed-Bandit (MAB) solver structure
class Agent() :

    selectedBanditAlgorithm = None
    param = 0
    arms = None
    numArms = None
    pulls = None
    max_pulls = None
    

    # initialization
    def __init__(self,
        selectedBanditAlgorithm=banditPolicy.RANDOM,
        param=0,
        init_arms=0,) :
        self.param = param
        self.selectedBanditAlgorithm = selectedBanditAlgorithm
        self.reset(init_arms)
        

    # reset memory structures (preparation for new testcase)
    def reset(self, numArms) :
        self.arms = [arm(m) for m in range(numArms)]
        self.numArms = numArms
        self.pulls = 0

    # select an arm from available stats
    def selectAction(self, increase_pulls=1) :

        if   self.selectedBanditAlgorithm == banditPolicy.RANDOM:   selected_arm = self.arms[random.randint(0, self.numArms - 1)]
        elif self.selectedBanditAlgorithm == banditPolicy.EGREEDY :  selected_arm = EGreedy(self.arms, self.param)
        elif self.selectedBanditAlgorithm == banditPolicy.SOFTMAX :  selected_arm = SoftMax(self.arms, self.param)
        elif self.selectedBanditAlgorithm == banditPolicy.UCB1 :     selected_arm = UCB1(self.arms, self.pulls, self.param)
        elif self.selectedBanditAlgorithm == banditPolicy.UCBT :     selected_arm = UCBT(self.arms, self.pulls, self.param)
        
        self.pulls += increase_pulls

        return selected_arm.id


    # update knowledge
    def updateKnowledge(self, arm_id, reward,suppress_output=0) :

        self.arms[arm_id].update(reward, self.pulls)
